package com.stahij.jarvis

import com.stahij.jarvis.DownloadPreflight.Network
import com.stahij.jarvis.DownloadPreflight.Verdict
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DownloadPreflightTest {
    private val plenty = 10L * 1_000_000_000L

    @Test
    fun wifiWithSpaceIsOk() {
        assertEquals(Verdict.Ok, DownloadPreflight.evaluate(plenty, 0, Network.WIFI, false))
    }

    @Test
    fun offlineIsReportedFirst() {
        assertEquals(Verdict.Offline, DownloadPreflight.evaluate(0, 0, Network.OFFLINE, false))
    }

    @Test
    fun mobileNeedsConfirmation() {
        assertEquals(
            Verdict.NeedsCellularConfirmation,
            DownloadPreflight.evaluate(plenty, 0, Network.CELLULAR, false)
        )
        assertEquals(Verdict.Ok, DownloadPreflight.evaluate(plenty, 0, Network.CELLULAR, true))
    }

    @Test
    fun notEnoughSpaceIsReported() {
        val verdict = DownloadPreflight.evaluate(1_000_000_000L, 0, Network.WIFI, false)
        assertTrue(verdict is Verdict.NotEnoughSpace)
    }

    @Test
    fun partialDownloadReducesNeededSpace() {
        val free = DownloadPreflight.EXPECTED_MODEL_BYTES / 2 + DownloadPreflight.SAFETY_MARGIN_BYTES
        assertTrue(DownloadPreflight.evaluate(free, 0, Network.WIFI, false) is Verdict.NotEnoughSpace)
        assertEquals(
            Verdict.Ok,
            DownloadPreflight.evaluate(free, DownloadPreflight.EXPECTED_MODEL_BYTES / 2, Network.WIFI, false)
        )
    }

    @Test
    fun formatsBytes() {
        // Decimal separator depends on the locale, so only the unit is checked here.
        assertTrue(DownloadPreflight.formatBytes(1_930_000_000L).endsWith(" ГБ"))
        assertEquals("300 МБ", DownloadPreflight.formatBytes(300_000_000L))
    }
}
