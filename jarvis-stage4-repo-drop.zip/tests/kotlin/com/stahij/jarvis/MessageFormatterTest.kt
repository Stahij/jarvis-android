package com.stahij.jarvis

import com.stahij.jarvis.MessageFormatter.Block
import org.junit.Assert.assertEquals
import org.junit.Test

class MessageFormatterTest {
    @Test
    fun plainTextIsOneBlock() {
        assertEquals(listOf<Block>(Block.Text("Привет, мир")), MessageFormatter.parse("Привет, мир"))
    }

    @Test
    fun codeBlockWithLanguageIsSeparated() {
        val blocks = MessageFormatter.parse("Вот код:\n```kotlin\nval x = 1\n```\nГотово.")
        assertEquals(
            listOf(
                Block.Text("Вот код:"),
                Block.Code("kotlin", "val x = 1"),
                Block.Text("Готово.")
            ),
            blocks
        )
    }

    @Test
    fun unclosedFenceWhileStreamingRunsToTheEnd() {
        val blocks = MessageFormatter.parse("Пример:\n```python\nprint(1)\nprint(2)")
        assertEquals(listOf(Block.Text("Пример:"), Block.Code("python", "print(1)\nprint(2)")), blocks)
    }

    @Test
    fun unsafeLanguageTagIsDropped() {
        val blocks = MessageFormatter.parse("```<script>\nx\n```")
        assertEquals(listOf<Block>(Block.Code("", "x")), blocks)
    }

    @Test
    fun speechSkipsCode() {
        val blocks = MessageFormatter.parse("Сначала текст.\n```\ncode()\n```\nПотом ещё текст.")
        assertEquals("Сначала текст.\nПотом ещё текст.", MessageFormatter.speakableText(blocks))
    }

    @Test
    fun emptyInputGivesNoBlocks() {
        assertEquals(emptyList<Block>(), MessageFormatter.parse(""))
    }
}
