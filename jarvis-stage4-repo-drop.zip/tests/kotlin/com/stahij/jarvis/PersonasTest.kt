package com.stahij.jarvis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Needs org.json on the JVM (see tests/kotlin/README.md). */
class PersonasTest {
    @Test
    fun overrideAppliesAndBlankIsIgnored() {
        val parsed = Personas.parse("""{"Переводчик":"Новая инструкция","Автор":"   ","Неизвестная":"x"}""")
        assertEquals("Новая инструкция", parsed["Переводчик"])
        assertFalse(parsed.containsKey("Автор"))
        assertFalse(parsed.containsKey("Неизвестная"))
    }

    @Test
    fun everyNameHasADefault() {
        Personas.NAMES.forEach { name ->
            assertTrue(!Personas.defaultsFor(name).isNullOrBlank())
        }
    }
}
