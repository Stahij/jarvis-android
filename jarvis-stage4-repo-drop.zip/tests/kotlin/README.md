# Тесты Kotlin (JVM, без эмулятора)

Файлы: `MessageFormatterTest`, `DownloadPreflightTest`, `PersonasTest` (+ существующие для `PromptSanitizer`, `ContextBudget`, `Versions`, если добавлены).

## Подключение (один раз)

В `app/build.gradle.kts` добавить блок (в проекте сейчас нет блока `dependencies`):

```kotlin
dependencies {
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")   // org.json в JVM-тестах — заглушка Android без этого
}
```

Файлы положить в `app/src/test/java/com/stahij/jarvis/` и запустить `gradle testDebugUnitTest`.

## Что уже проверено без компилятора

Логика `MessageFormatter.parse` и `DownloadPreflight.evaluate` сверена зеркальным расчётом на Python. Kotlin-компилятор в среде не запускался: ожидайте возможных мелких правок синтаксиса при первом прогоне.
