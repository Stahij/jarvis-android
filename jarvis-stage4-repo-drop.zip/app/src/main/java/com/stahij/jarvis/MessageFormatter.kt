package com.stahij.jarvis

/**
 * Splits a model reply into text and fenced code blocks (```lang ... ```).
 *
 * Pure Kotlin on purpose (no Android classes) so it can be unit-tested on the JVM.
 * An UNCLOSED fence is treated as a code block that runs to the end: this is what happens while
 * the answer is still streaming, and it stops the rest of the text from looking like code.
 * Inline markdown (bold, lists) is left as plain text in this stage.
 */
object MessageFormatter {
    sealed class Block {
        data class Text(val text: String) : Block()
        data class Code(val language: String, val code: String) : Block()
    }

    private val safeLanguage = Regex("^[A-Za-z0-9_+.#-]{1,20}$")

    fun parse(input: String): List<Block> {
        if (input.isEmpty()) return emptyList()
        val blocks = mutableListOf<Block>()
        val text = StringBuilder()
        val code = StringBuilder()
        var inCode = false
        var language = ""

        fun flushText() {
            val value = text.toString().trim('\n')
            if (value.isNotBlank()) blocks.add(Block.Text(value))
            text.setLength(0)
        }

        for (line in input.split("\n")) {
            val trimmed = line.trimStart()
            when {
                !inCode && trimmed.startsWith("```") -> {
                    flushText()
                    inCode = true
                    language = trimmed.removePrefix("```").trim().takeIf { safeLanguage.matches(it) }.orEmpty()
                    code.setLength(0)
                }
                inCode && trimmed.startsWith("```") -> {
                    blocks.add(Block.Code(language, code.toString().trimEnd('\n')))
                    inCode = false
                    language = ""
                    code.setLength(0)
                }
                inCode -> code.append(line).append('\n')
                else -> text.append(line).append('\n')
            }
        }
        if (inCode) blocks.add(Block.Code(language, code.toString().trimEnd('\n')))
        else flushText()
        return blocks
    }

    /** Text to read aloud: code is skipped entirely, it is not useful spoken. */
    fun speakableText(blocks: List<Block>): String =
        blocks.filterIsInstance<Block.Text>().joinToString("\n") { it.text }.trim()
}
