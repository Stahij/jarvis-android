package com.stahij.jarvis

/**
 * Decides whether the 1.9 GB model download may start. Pure Kotlin: the Android inputs
 * (free space, network type) are read in [DeviceNetwork] and passed in.
 */
object DownloadPreflight {
    /** Size of the Qwen 2.5 3B Q4_K_M file. The real check stays the size and GGUF checks after download. */
    const val EXPECTED_MODEL_BYTES = 1_930_000_000L

    /** Room kept free for the app, the unpacked files and the system. */
    const val SAFETY_MARGIN_BYTES = 300L * 1024L * 1024L

    enum class Network { WIFI, CELLULAR, OFFLINE, OTHER }

    sealed class Verdict {
        object Ok : Verdict()
        object Offline : Verdict()
        object NeedsCellularConfirmation : Verdict()
        data class NotEnoughSpace(val neededBytes: Long, val freeBytes: Long) : Verdict()
    }

    /**
     * [alreadyDownloadedBytes] is the size of an interrupted `.part` file: it is not downloaded again,
     * so it reduces the space needed.
     */
    fun evaluate(
        freeBytes: Long,
        alreadyDownloadedBytes: Long,
        network: Network,
        confirmedCellular: Boolean
    ): Verdict {
        if (network == Network.OFFLINE) return Verdict.Offline
        val remaining = maxOf(0L, EXPECTED_MODEL_BYTES - maxOf(0L, alreadyDownloadedBytes))
        val needed = remaining + SAFETY_MARGIN_BYTES
        if (freeBytes < needed) return Verdict.NotEnoughSpace(needed, freeBytes)
        if (network == Network.CELLULAR && !confirmedCellular) return Verdict.NeedsCellularConfirmation
        return Verdict.Ok
    }

    fun formatBytes(bytes: Long): String =
        if (bytes >= 1_000_000_000L) String.format("%.1f ГБ", bytes / 1_000_000_000.0)
        else "${bytes / 1_000_000L} МБ"
}
