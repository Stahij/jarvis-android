package com.stahij.jarvis

import android.content.Context
import org.json.JSONObject

/**
 * Persona instructions. The defaults live here; `assets/personas.json` overrides any of them
 * (edit the JSON, no code change). A missing or broken JSON silently falls back to the defaults.
 */
object Personas {
    const val ASSET_NAME = "personas.json"
    const val DEFAULT_NAME = "Общий помощник"
    val NAMES = listOf(
        DEFAULT_NAME, "Переводчик", "Программист", "Собеседник", "Флирт", "Поддержка", "Автор"
    )

    private val defaults: Map<String, String> = mapOf(
        DEFAULT_NAME to "Будь универсальным персональным помощником: сначала отвечай прямо, затем при необходимости добавляй практические шаги.",
        "Переводчик" to "Переводи точно и естественно. Сохраняй смысл, тон и структуру. Если язык не указан, определи его по контексту и уточни целевой язык при необходимости.",
        "Программист" to "Работай как опытный разработчик: сначала уточняй требования при существенной неоднозначности, предлагай проверяемые решения, учитывай ошибки и безопасность. Не утверждай, что запускал код, если запуска не было.",
        "Собеседник" to "Будь живым, внимательным и доброжелательным собеседником. Поддерживай естественный диалог, не превращай каждый ответ в инструкцию.",
        "Флирт" to "Общайся легко, тепло и игриво, уважая границы собеседника. Не дави и не выдавай себя за реального человека.",
        "Поддержка" to "Помогай человеку осмыслить ситуацию бережно, задавай открытые вопросы и не ставь диагнозов. Ты не заменяешь психолога или медицинского специалиста.",
        "Автор" to "Помогай писать и редактировать тексты. Сохраняй авторский замысел, предлагай ясные формулировки и отмечай существенные правки."
    )

    @Volatile
    private var overrides: Map<String, String>? = null

    /** Parses the JSON object {"name": "instruction", ...}. Unknown keys and blank values are ignored. */
    fun parse(json: String): Map<String, String> {
        val root = JSONObject(json)
        return NAMES.mapNotNull { name ->
            root.optString(name, "").trim().takeIf { it.isNotEmpty() }?.let { name to it }
        }.toMap()
    }

    fun promptFor(context: Context, name: String): String {
        val map = overrides ?: loadOverrides(context).also { overrides = it }
        return map[name] ?: defaults[name] ?: defaults.getValue(DEFAULT_NAME)
    }

    private fun loadOverrides(context: Context): Map<String, String> = try {
        context.applicationContext.assets.open(ASSET_NAME).bufferedReader(Charsets.UTF_8).use { parse(it.readText()) }
    } catch (_: Exception) {
        emptyMap()
    }

    /** Built-in defaults, exposed for tests and for the fallback check. */
    fun defaultsFor(name: String): String? = defaults[name]
}
