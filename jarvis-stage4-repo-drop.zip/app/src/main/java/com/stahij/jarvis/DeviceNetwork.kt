package com.stahij.jarvis

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.StatFs
import java.io.File

/** Android side of [DownloadPreflight]: reads free space and the active network type. */
object DeviceNetwork {
    fun freeBytes(directory: File): Long = try {
        StatFs(directory.path).availableBytes
    } catch (_: Exception) {
        Long.MAX_VALUE   // unknown: do not block the download on a measurement error
    }

    fun current(context: Context): DownloadPreflight.Network {
        val manager = context.getSystemService(ConnectivityManager::class.java)
            ?: return DownloadPreflight.Network.OTHER
        val active = manager.activeNetwork ?: return DownloadPreflight.Network.OFFLINE
        val caps = manager.getNetworkCapabilities(active) ?: return DownloadPreflight.Network.OTHER
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> DownloadPreflight.Network.WIFI
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> DownloadPreflight.Network.CELLULAR
            else -> DownloadPreflight.Network.OTHER
        }
    }
}
