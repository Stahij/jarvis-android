#pragma once
#include <cstdint>
#include <cstddef>
typedef int32_t jint; typedef int8_t jbyte; typedef int32_t jsize; typedef bool jboolean;
struct _jobject {}; typedef _jobject* jobject; typedef jobject jclass; typedef jobject jstring;
typedef jobject jobjectArray; typedef jobject jbyteArray; typedef void* jmethodID;
#define JNIEXPORT
#define JNICALL
struct JNIEnv {
  jsize GetArrayLength(jobject); jobject GetObjectArrayElement(jobjectArray, jsize);
  const char* GetStringUTFChars(jstring, jboolean*); void ReleaseStringUTFChars(jstring, const char*);
  void DeleteLocalRef(jobject); jbyteArray NewByteArray(jsize);
  void SetByteArrayRegion(jbyteArray, jsize, jsize, const jbyte*);
  void GetByteArrayRegion(jbyteArray, jsize, jsize, jbyte*);
  jclass FindClass(const char*); jint ThrowNew(jclass, const char*);
  jclass GetObjectClass(jobject); jmethodID GetMethodID(jclass, const char*, const char*);
  void CallVoidMethod(jobject, jmethodID, ...); jboolean ExceptionCheck(); void ExceptionClear();
  jstring NewStringUTF(const char*);
};
