#pragma once
#define ANDROID_LOG_ERROR 6
int __android_log_print(int, const char*, const char*, ...);
