#pragma once
#include <cstdint>
#include <cstddef>
typedef int32_t llama_token; typedef int32_t llama_pos; typedef int32_t llama_seq_id;
struct llama_model; struct llama_context; struct llama_sampler; struct llama_vocab; struct llama_memory_i; typedef llama_memory_i* llama_memory_t;
struct llama_chat_message { const char* role; const char* content; };
struct llama_batch { int dummy; };
struct llama_model_params { int n_gpu_layers; }; struct llama_context_params { uint32_t n_ctx; uint32_t n_batch; uint32_t n_ubatch; int n_threads; int n_threads_batch; };
struct llama_sampler_chain_params { int x; };
#define LLAMA_DEFAULT_SEED 0xFFFFFFFF
void llama_backend_init(); llama_model_params llama_model_default_params(); llama_context_params llama_context_default_params();
llama_model* llama_model_load_from_file(const char*, llama_model_params); void llama_model_free(llama_model*);
llama_context* llama_init_from_model(llama_model*, llama_context_params); void llama_free(llama_context*);
llama_sampler_chain_params llama_sampler_chain_default_params(); llama_sampler* llama_sampler_chain_init(llama_sampler_chain_params);
void llama_sampler_chain_add(llama_sampler*, llama_sampler*); llama_sampler* llama_sampler_init_top_k(int32_t);
llama_sampler* llama_sampler_init_top_p(float, size_t); llama_sampler* llama_sampler_init_temp(float); llama_sampler* llama_sampler_init_dist(uint32_t);
void llama_sampler_free(llama_sampler*); void llama_sampler_reset(llama_sampler*); llama_token llama_sampler_sample(llama_sampler*, llama_context*, int32_t);
const char* llama_model_chat_template(const llama_model*, const char*);
int32_t llama_chat_apply_template(const char*, const llama_chat_message*, size_t, bool, char*, int32_t);
const llama_vocab* llama_model_get_vocab(const llama_model*);
int32_t llama_tokenize(const llama_vocab*, const char*, int32_t, llama_token*, int32_t, bool, bool);
llama_memory_t llama_get_memory(const llama_context*); llama_pos llama_memory_seq_pos_max(llama_memory_t, llama_seq_id);
bool llama_memory_seq_rm(llama_memory_t, llama_seq_id, llama_pos, llama_pos); void llama_memory_clear(llama_memory_t, bool);
llama_batch llama_batch_get_one(llama_token*, int32_t); int32_t llama_decode(llama_context*, llama_batch);
enum llama_vocab_type { LLAMA_VOCAB_TYPE_NONE=0, LLAMA_VOCAB_TYPE_SPM=1, LLAMA_VOCAB_TYPE_BPE=2 };
enum llama_vocab_type llama_vocab_type(const llama_vocab*);
bool llama_vocab_is_eog(const llama_vocab*, llama_token); int32_t llama_token_to_piece(const llama_vocab*, llama_token, char*, int32_t, int32_t, bool);
