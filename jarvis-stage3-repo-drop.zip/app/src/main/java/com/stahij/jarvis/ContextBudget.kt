package com.stahij.jarvis

/**
 * Token budgeting for the extra context (GitHub files, saved notes) that is attached to a request.
 *
 * Without it, a long context pushes the prompt over the native limit; the native side then drops
 * old chat history and, if that is not enough, refuses the request. The estimate is deliberately
 * conservative; calibrate it with the `estimated_tokens` vs `prompt_tokens` values that
 * LlmEngine writes to diagnostics.
 */
object ContextBudget {
    /** Keep in sync with MAX_PROMPT_TOKENS in native-lib.cpp. */
    const val PROMPT_TOKEN_LIMIT = 3072
    /** Chat-template tokens plus estimation error. */
    const val SAFETY_TOKENS = 250
    /** Upper bound for attached context even when there is more room. */
    const val MAX_CONTEXT_TOKENS = 2000
    /** Below this a context is not worth attaching. */
    const val MIN_USEFUL_CONTEXT_TOKENS = 200

    private const val CYRILLIC_CHARS_PER_TOKEN = 2.0
    private const val OTHER_CHARS_PER_TOKEN = 2.8
    private const val TRUNCATION_NOTE = "\n[…контекст обрезан по лимиту…]"

    fun estimateTokens(text: String): Int {
        if (text.isEmpty()) return 0
        var cyrillic = 0
        var other = 0
        for (ch in text) {
            if (ch in '\u0400'..'\u04FF') cyrillic++ else other++
        }
        return Math.ceil(cyrillic / CYRILLIC_CHARS_PER_TOKEN + other / OTHER_CHARS_PER_TOKEN).toInt() + 1
    }

    /** Cuts [text] (on a line boundary when possible) so that its estimate fits [maxTokens]. */
    fun fitToTokens(text: String, maxTokens: Int): String {
        if (maxTokens <= 0 || text.isEmpty()) return ""
        if (estimateTokens(text) <= maxTokens) return text
        val noteTokens = estimateTokens(TRUNCATION_NOTE)
        var end = (text.length.toLong() * maxTokens / estimateTokens(text)).toInt().coerceIn(0, text.length)
        var cut = text.take(end)
        while (end > 0 && estimateTokens(cut) > maxTokens - noteTokens) {
            end = (end * 0.9).toInt()
            cut = text.take(end)
        }
        val lastBreak = cut.lastIndexOf('\n')
        if (lastBreak > cut.length * 0.6) cut = cut.substring(0, lastBreak)
        if (cut.isNotEmpty() && cut.last().isHighSurrogate()) cut = cut.dropLast(1)
        return cut.trimEnd() + TRUNCATION_NOTE
    }
}
