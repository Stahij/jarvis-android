package com.stahij.jarvis

/** Version helpers kept free of Android classes so they can be unit-tested on the JVM. */
object Versions {
    private val valid = Regex("^\\d+(\\.\\d+){1,3}([-+][0-9A-Za-z.]+)?$")

    /** True for tags like 1.5.6 or 1.6.0-rc1 (after the leading "v" is removed). */
    fun isValid(version: String): Boolean = valid.matches(version)

    /** Numeric, component-wise comparison: 1.10.0 > 1.9.9. Non-numeric parts count as 0. */
    fun compare(left: String, right: String): Int {
        val a = left.split(".", "-", "+").map { it.toIntOrNull() ?: 0 }
        val b = right.split(".", "-", "+").map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(a.size, b.size)) {
            val diff = (a.getOrNull(i) ?: 0).compareTo(b.getOrNull(i) ?: 0)
            if (diff != 0) return diff
        }
        return 0
    }
}
