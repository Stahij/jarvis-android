package com.stahij.jarvis

/**
 * Defence in depth for text that comes from outside the app: repository files, saved notes, web pages.
 *
 * The native tokenizer already keeps message bodies from turning into control tokens
 * (see tokenize_chat_safe in native-lib.cpp). This covers what it cannot:
 *  1. models whose vocabulary is not tokenized in safe mode (the native side falls back);
 *  2. forgery of OUR envelope tags such as </repository_file>, which would let data escape its fence.
 *
 * Rules:
 *  - sanitize at the boundary where untrusted data enters (file bodies, paths, notes), never the
 *    finished prompt, otherwise our own tags would be broken too;
 *  - idempotent: applying it twice changes nothing more.
 */
object PromptSanitizer {
    private const val ZWSP = "\u200B"

    // Our own fences plus markers some chat formats treat as structure.
    private val envelopeTag = Regex(
        "<(/?)(repository_file|saved_knowledge|untrusted_data|tool_call|tool_response|tools|think|s|unk|pad|mask)(?=[\\s>/])",
        RegexOption.IGNORE_CASE
    )

    fun neutralize(text: String): String {
        if (text.isEmpty()) return text
        return text
            .replace("<|", "<$ZWSP|")
            .replace("|>", "|$ZWSP>")
            .replace(envelopeTag) { match -> "<$ZWSP" + match.groupValues[1] + match.groupValues[2] }
            .replace("<<SYS>>", "<<${ZWSP}SYS>>")
            .replace("<</SYS>>", "<<$ZWSP/SYS>>")
            .replace("[INST]", "[${ZWSP}INST]")
            .replace("[/INST]", "[$ZWSP/INST]")
    }
}
