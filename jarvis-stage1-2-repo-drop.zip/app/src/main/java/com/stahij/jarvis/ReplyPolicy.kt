package com.stahij.jarvis

/**
 * Decides what is stored in the chat history and what is only shown in the UI.
 *
 * Pure function on purpose: no Android classes, easy to unit-test.
 * [Final.text] goes to history EXACTLY as the model produced it (so the next prompt keeps matching
 * the native KV cache); [Final.note] is a UI-only suffix.
 */
object ReplyPolicy {
    data class Final(val text: String, val note: String)

    fun finalize(generated: String, perf: String, toolContext: String): Final {
        val aborted = perf.contains("finish_reason=aborted")
        // Small local models may ignore a long repository context and fall back to generic advice.
        // Never present that as repository analysis: show a provenance-backed receipt instead.
        val text = if (!aborted && toolContext.contains("GitHub: ДАННЫЕ ПОЛУЧЕНЫ УСПЕШНО") &&
            (generated.isBlank() ||
                generated.contains("откройте github", ignoreCase = true) ||
                generated.contains("откройте репозиторий", ignoreCase = true) ||
                generated.contains("перейдите на github", ignoreCase = true) ||
                generated.contains("я не могу получить доступ", ignoreCase = true))
        ) {
            GitHubChatTool.buildReadReceipt(toolContext, generated)
        } else generated
        val note = when {
            perf.contains("finish_reason=token_limit") -> "\n\n[Ответ достиг лимита 1024 токена. Напиши «Продолжи».]"
            aborted -> "\n\n[Остановлено]"
            else -> ""
        }
        return Final(text, note)
    }
}
