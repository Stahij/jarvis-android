package com.stahij.jarvis

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Owns one chat turn from "user pressed send" to "answer ready": tool context, generation, post-processing.
 *
 * It lives in the process, not in an Activity, so a turn survives closing the screen, rotation and
 * switching apps ([LlmService] keeps the process alive and shows the notification).
 *
 * The UI attaches a [Listener]. If nobody is attached when the turn ends, the reply is parked in
 * SharedPreferences and handed over by [takePendingReply] the next time the UI starts.
 *
 * Threading: [submit], [attach], [detach] and all [Listener] callbacks run on the main thread;
 * the turn itself runs on one worker thread. Shared state is guarded by [lock].
 */
object LlmEngine {
    data class TurnRequest(
        val roles: List<String>,
        val contents: List<String>,
        /** Raw user text, used to decide on tools and to look up saved notes. */
        val userPrompt: String,
        val maxTokens: Int = 1024
    )

    /** [text] is what belongs in history; [note] is shown in the UI only; [error] is set on failure. */
    data class Reply(val text: String, val note: String, val error: String?, val aborted: Boolean)

    /** State of a running turn for a UI that attaches late. */
    data class Snapshot(val partial: String, val status: String)

    interface Listener {
        fun onStatus(text: String)
        fun onToken(piece: String)
        fun onFinished(reply: Reply)
    }

    private const val PREFS = "jarvis_llm"
    private const val KEY_PENDING = "pending"
    private const val KEY_TEXT = "pending_text"
    private const val KEY_NOTE = "pending_note"
    private const val KEY_ERROR = "pending_error"
    private const val KEY_ABORTED = "pending_aborted"

    private val lock = Any()
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "jarvis-llm") }
    private val stopRequested = AtomicBoolean(false)
    private val flushScheduled = AtomicBoolean(false)

    // Guarded by lock:
    private var listener: Listener? = null
    private var busy = false
    private var status = ""
    private val partial = StringBuilder()
    private var delivered = 0   // how much of `partial` the current listener has already received

    /** Starts a turn. Returns false if one is already running. Call from the main thread (the app is visible). */
    fun submit(context: Context, request: TurnRequest): Boolean {
        val app = context.applicationContext
        synchronized(lock) {
            if (busy) return false
            busy = true
            status = "ДУМАЮ..."
            partial.setLength(0)
            delivered = 0
        }
        stopRequested.set(false)
        try {
            LlmService.start(app)
        } catch (e: Exception) {
            // Without the service the turn still works while the app stays in the foreground.
            JarvisDiagnostics.event(app, "service_start_failed", e.javaClass.simpleName + ": " + (e.message ?: ""))
        }
        worker.execute { runTurn(app, request) }
        return true
    }

    /** Asks the running turn to stop: cancels the tool phase and aborts native decoding within one token. */
    fun stop() {
        if (!isBusy()) return
        stopRequested.set(true)
        NativeLlm.abort()
    }

    fun isBusy(): Boolean = synchronized(lock) { busy }

    /** Registers the UI. Returns the running turn's state, or null when idle. */
    fun attach(l: Listener): Snapshot? = synchronized(lock) {
        listener = l
        delivered = partial.length
        if (busy) Snapshot(partial.toString(), status) else null
    }

    fun detach(l: Listener) {
        synchronized(lock) { if (listener === l) listener = null }
    }

    /** Returns (once) a reply that finished while no UI was attached. */
    fun takePendingReply(context: Context): Reply? {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return synchronized(lock) {
            if (!prefs.getBoolean(KEY_PENDING, false)) {
                null
            } else {
                val reply = Reply(
                    text = prefs.getString(KEY_TEXT, "") ?: "",
                    note = prefs.getString(KEY_NOTE, "") ?: "",
                    error = prefs.getString(KEY_ERROR, null),
                    aborted = prefs.getBoolean(KEY_ABORTED, false)
                )
                prefs.edit().clear().apply()
                reply
            }
        }
    }

    // ---- worker thread ----

    private fun runTurn(app: Context, req: TurnRequest) {
        try {
            val toolContext = if (GitHubChatTool.shouldUse(req.userPrompt)) {
                publishStatus("ИЗУЧАЮ GITHUB...")
                try {
                    GitHubChatTool.loadContext(req.userPrompt, app)
                } catch (toolError: Exception) {
                    "GitHub-инструмент не смог получить данные: ${toolError.message}. Не утверждай, что репозиторий изучен."
                }
            } else ""
            val knowledgeContext = KnowledgeStore.buildContext(app, req.userPrompt)

            // Keep the stable system prompt at the beginning. Put retrieved context beside the current
            // user request so old turns can be dropped without discarding core instructions.
            val contents = req.contents.toMutableList()
            if (toolContext.isNotBlank() || knowledgeContext.isNotBlank()) {
                val contextBlock = buildString {
                    append("\n\nДОПОЛНИТЕЛЬНЫЙ КОНТЕКСТ ДЛЯ ТЕКУЩЕГО ЗАПРОСА:\n")
                    if (knowledgeContext.isNotBlank()) append(knowledgeContext.take(1800)).append("\n")
                    if (toolContext.isNotBlank()) append(toolContext.take(7000)).append("\n")
                    append("Используй только относящиеся к вопросу факты и указывай, если данных недостаточно.")
                }
                val lastUserIndex = req.roles.indexOfLast { it == "user" }
                val target = if (lastUserIndex > 0) lastUserIndex else 0
                contents[target] = contents[target] + contextBlock
            }

            if (stopRequested.get()) {
                finishTurn(app, Reply("", "", null, aborted = true))
                return
            }

            val startedAt = SystemClock.elapsedRealtime()
            val cpuStartedAt = android.os.Process.getElapsedCpuTime()
            val promptChars = contents.sumOf { it.length }
            JarvisDiagnostics.event(app, "generation_start", "messages=${req.roles.size}; prompt_chars=$promptChars; max_output_tokens=${req.maxTokens}")

            var firstPiece = true
            val generated = NativeLlm.generate(req.roles, contents, req.maxTokens) { piece ->
                synchronized(lock) { partial.append(piece) }
                if (firstPiece) {
                    firstPiece = false
                    publishStatus("ПИШУ...")
                }
                scheduleFlush()
            }.trim()

            val perf = NativeLlm.nativeGetLastPerf()
            val durationMs = SystemClock.elapsedRealtime() - startedAt
            val cpuMs = android.os.Process.getElapsedCpuTime() - cpuStartedAt
            val approxWords = generated.split(Regex("\\s+")).count { it.isNotBlank() }
            JarvisDiagnostics.event(
                app, "generation_end",
                "duration_ms=$durationMs; $perf; process_cpu_ms=$cpuMs; output_chars=${generated.length}; " +
                    "approx_words=$approxWords; approx_words_per_sec=${if (durationMs > 0) approxWords * 1000L / durationMs else 0}"
            )

            val fin = ReplyPolicy.finalize(generated, perf, toolContext)
            finishTurn(app, Reply(fin.text, fin.note, null, perf.contains("finish_reason=aborted")))
        } catch (t: Throwable) {
            JarvisDiagnostics.event(app, "generation_error", t.javaClass.simpleName + ": " + (t.message ?: ""))
            finishTurn(app, Reply("", "", t.message ?: "Ошибка локальной генерации", false))
        }
    }

    private fun publishStatus(text: String) {
        synchronized(lock) { status = text }
        main.post {
            val l = synchronized(lock) { listener }
            l?.onStatus(text)
        }
    }

    // Tokens are pulled, not pushed: the main thread sends whatever the listener has not seen yet.
    // That makes late attach safe (no duplicated or lost text) and coalesces UI updates.
    private fun scheduleFlush() {
        if (flushScheduled.compareAndSet(false, true)) {
            main.post {
                flushScheduled.set(false)
                flushNow()
            }
        }
    }

    private fun flushNow() {
        var target: Listener? = null
        var chunk = ""
        synchronized(lock) {
            val l = listener
            if (l != null && partial.length > delivered) {
                chunk = partial.substring(delivered)
                delivered = partial.length
                target = l
            }
        }
        target?.onToken(chunk)
    }

    private fun finishTurn(app: Context, reply: Reply) {
        synchronized(lock) {
            busy = false
            status = ""
        }
        main.post {
            flushNow()  // the tail of the stream first, then the final reply
            val l = synchronized(lock) { listener }
            if (l != null) l.onFinished(reply) else storePending(app, reply)
            LlmService.stopWhenIdle()
        }
    }

    private fun storePending(app: Context, reply: Reply) {
        synchronized(lock) {
            app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_PENDING, true)
                .putString(KEY_TEXT, reply.text)
                .putString(KEY_NOTE, reply.note)
                .putString(KEY_ERROR, reply.error)
                .putBoolean(KEY_ABORTED, reply.aborted)
                .apply()
        }
    }
}
