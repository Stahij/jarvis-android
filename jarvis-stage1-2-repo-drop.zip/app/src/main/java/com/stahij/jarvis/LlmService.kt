package com.stahij.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/**
 * Keeps the process alive (foreground notification + CPU wake lock) while [LlmEngine] works on a turn.
 * It holds no model or chat state of its own; the engine does the work.
 *
 * Lifecycle: the Activity calls [start] when the user presses send (the app is visible, so a
 * foreground start is allowed). When the engine finishes it calls [stopWhenIdle].
 * onStartCommand always calls startForeground first, as Android requires after startForegroundService.
 */
class LlmService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            LlmEngine.stop()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification())
        if (!LlmEngine.isBusy()) {
            // The turn finished (or failed) before the service got going.
            shutDown()
            return START_NOT_STICKY
        }
        acquireWakeLock()
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        releaseWakeLock()
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun shutDown() {
        releaseWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:llm").apply {
            setReferenceCounted(false)
            acquire(WAKE_LOCK_TIMEOUT_MS)   // safety net; released as soon as the turn ends
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun buildNotification(): Notification {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Jarvis: ответ модели", NotificationManager.IMPORTANCE_LOW)
        )
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, LlmService::class.java).setAction(ACTION_STOP), flags
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Jarvis думает")
            .setContentText("Локальная модель готовит ответ")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Стоп", stop).build())
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "jarvis_llm"
        private const val NOTIFICATION_ID = 4107
        private const val ACTION_STOP = "com.stahij.jarvis.action.LLM_STOP"
        private const val WAKE_LOCK_TIMEOUT_MS = 15 * 60 * 1000L

        @Volatile
        private var instance: LlmService? = null

        fun start(context: Context) {
            context.startForegroundService(Intent(context, LlmService::class.java))
        }

        /** Stops the service unless a new turn has started in the meantime. Safe from any thread. */
        fun stopWhenIdle() {
            val service = instance ?: return   // not created yet: its onStartCommand will see the idle engine
            Handler(Looper.getMainLooper()).post {
                if (!LlmEngine.isBusy()) service.shutDown()
            }
        }
    }
}
